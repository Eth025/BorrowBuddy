//
//  BorrowBoxApp.swift
//  BorrowBox
//
//  Created by Ethan  on 3/5/2025.
//

import SwiftUI

@main
struct BorrowBuddyApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}

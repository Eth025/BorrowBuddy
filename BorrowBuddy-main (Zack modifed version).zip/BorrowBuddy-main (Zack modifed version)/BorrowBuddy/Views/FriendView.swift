//
//  FriendView.swift
//  BorrowBuddy
//
//  Created by Ethan  on 7/5/2025.
//  Coded by Vivek
//  Modified by Zack on 12/5/2025

import SwiftUI

// View for displaying & managing  user's friends list
struct FriendView: View {
    
    @State private var friends: [String] = ["Angelina", "Ethan", "Zack", "Vivek", "Alice", "Dylan", "Diana"]
    @State private var showingAddFriend = false
    // Controls whether the AddFriendView sheet is shown
    @State private var searchText: String = ""
    // Stores the user's search query

    // Filters & sorts friends based on the search text.
    // Friends whose names start with the search text appear first.
    private var filteredFriends: [String] {
        if searchText.isEmpty {
            return friends
        } else {
            return friends
                .filter { $0.lowercased().contains(searchText.lowercased()) }
                .sorted {
                    $0.lowercased().hasPrefix(searchText.lowercased()) &&
                    !$1.lowercased().hasPrefix(searchText.lowercased())
                }
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                // Set the background colour using a custom hex initializer
                Color(hex: "#dbd6d2")
                    .edgesIgnoringSafeArea(.all)

                VStack(alignment: .leading, spacing: 20) {
                    
                    //App Logo at Top
                    Image(uiImage: #imageLiteral(resourceName: "BorrowBuddyLogo.png"))
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 180)
                        .offset(y: -30)
                        .padding(.bottom, -60)

                    //Header Title & Add Friend Button
                    HStack {
                        Text("Friends")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundColor(.black)
                        Spacer()
                        Button(action: {
                            showingAddFriend = true
                        }) {
                            Image(systemName: "plus.circle.fill")
                                .font(.title)
                                .foregroundColor(.blue)
                        }
                    }
                    .padding(.horizontal)

                    //Section Title
                    Text("Current Friends")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.black)
                        .padding(.horizontal)

                    //Search Bar
                    TextField("Search friends", text: $searchText)
                        .padding(10)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                        .padding(.horizontal, 20)

                    //Friends List
                    ScrollView {
                        VStack(spacing: 10) {
                            if filteredFriends.isEmpty {
                                // If no matching friends found
                                Text("No friends found.")
                                    .foregroundColor(.white)
                                    .padding()
                            } else {
                                // Display each filtered friend
                                ForEach(filteredFriends, id: \.self) { friend in
                                    HStack {
                                        Text(friend)
                                            .foregroundColor(.black)
                                        Text("(Click to view their profile)")
                                            .foregroundColor(.gray)
                                            .italic()
                                    }
                                    .padding()
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .background(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color.white, lineWidth: 1)
                                            .background(Color.white.opacity(0.1))
                                    )
                                }
                            }
                        }
                        .padding(.horizontal)
                    }

                    Spacer()
                }
                .padding(.top)

                //Add Friend Modal Sheet
                .sheet(isPresented: $showingAddFriend) {
                    AddFriendView { newFriend in
                        // Only add if not already in the list
                        if !friends.contains(newFriend) {
                            friends.append(newFriend)
                        }
                    }
                }

                // Built-in searchable modifier for better search UX
                .searchable(text: $searchText, prompt: "Search friends")
                
                // Hide the default navigation bar
                .navigationTitle("")
                .navigationBarHidden(true)
            }
        }
    }
}

#Preview {
    FriendView()
}

//Created by Ethan on 7/5/25
// Modified by Zack on 11/5/2025


import SwiftUI
import Foundation

// Main view for the login screen
struct LoginView: View {
    @StateObject private var user = UserModel()
    // Holds user data, shared across views
    @State private var navigationOn = false
    // Controls navigation to the main app view

    var body: some View {
        NavigationView {
            ZStack {
                // Background color
                Color(hex: "#dbd6d2")
                    .edgesIgnoringSafeArea(.all)

                // Decorative circles in the background
                Circle() // Circle #1
                    .fill(Color.white.opacity(0.2))
                    .frame(width: 300, height: 300)
                    .offset(x: -150, y: -400)

                Circle() // Circle #2
                    .fill(Color.white.opacity(0.15))
                    .frame(width: 200, height: 200)
                    .offset(x: 200, y: 20)

                Circle() // Circle #3
                    .fill(Color.white.opacity(0.1))
                    .frame(width: 250, height: 250)
                    .offset(x: -200, y: 200)

                VStack {
                    Spacer().frame(height: 40)

                    // App logo image
                    Image(uiImage: #imageLiteral(resourceName: "BorrowBuddyLogo.png"))
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 180)
                        .offset(y: -30) // Adjust vertical position
                        .padding(.bottom, -30)

                    // Decorative book image
                    Image("Book")
                        .resizable()
                        .frame(width: 200, height: 200)
                        .padding(.bottom, 50)

                    // Text field for user to enter name
                    Name()
                        .padding(.bottom, 20)

                    // Login button
                    LoginButton(navigationOn: $navigationOn)

                    // Hidden NavigationLink to transition to main app when logged in
                    NavigationLink(destination: MainAppView().onAppear {
                        user.loadSampleData() // Load sample data on login
                    }, isActive: $navigationOn) {
                        EmptyView()
                    }
                }
                .padding()
            }
        }
        .environmentObject(user)
        // Make user model available to all child views
    }
}

#Preview {
    LoginView()
}

//Name Entry Subview
struct Name: View {
    @EnvironmentObject var user: UserModel
    // Access shared user model

    var body: some View {
        VStack {
            TextField("Name", text: $user.name)
            // User input for name
                .padding()
                .background(Color(.systemGray6))
            // Light grey background
                .cornerRadius(5.0)
        }
        .padding(.horizontal, 30)
    }
}

//Login Button Subview
struct LoginButton: View {
    @EnvironmentObject var user: UserModel
    @Binding var navigationOn: Bool
    // Binding to control navigation

    var body: some View {
        Button(action: {
            // Proceed only if the name field is not empty
            if !user.name.trimmingCharacters(in: .whitespaces).isEmpty {
                navigationOn = true
            }
        }) {
            Text("LOGIN")
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .frame(width: 260, height: 60)
                .background(Color.black)
                .cornerRadius(38.0)
        }
    }
}

//Custom Colour Extension

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64

        switch hex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17,
                            (int >> 4 & 0xF) * 17,
                            (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16,
                            int >> 8 & 0xFF,
                            int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24,
                            int >> 16 & 0xFF,
                            int >> 8 & 0xFF,
                            int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }

        self.init(.sRGB,
                  red: Double(r) / 255,
                  green: Double(g) / 255,
                  blue: Double(b) / 255,
                  opacity: Double(a) / 255)
    }
}

